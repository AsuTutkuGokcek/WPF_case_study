﻿namespace LevelBarApp.ViewModels
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Windows;
    using GalaSoft.MvvmLight;
    using GalaSoft.MvvmLight.Command;
    using LevelBarGeneration;

    /// <summary>
    /// MainWindowViewModel
    /// </summary>
    /// <seealso cref="ViewModelBase" />

    public class MainWindowViewModel : ViewModelBase
    {
        // Fields
        private readonly LevelBarGenerator levelBarGenerator;
        private RelayCommand connectToGeneratorCommand;
        private RelayCommand disconnectToGeneratorCommand;

        private readonly Dictionary<int, float> peakHoldValues = new Dictionary<int, float>();

        // Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
        /// </summary>
        public MainWindowViewModel()
        {
            levelBarGenerator = LevelBarGenerator.Instance;

            levelBarGenerator.GeneratorStateChanged += LevelBarGenerator_GeneratorStateChanged;
            levelBarGenerator.ChannelAdded += LevelBarGenerator_ChannelAdded;
            levelBarGenerator.ChannelLevelDataReceived += LevelBarGenerator_ChannelDataReceived;
            levelBarGenerator.ChannelRemoved += LevelBarGenerator_ChannelRemoved;
        }

        // Properties

        /// <summary>
        /// Gets or sets the level bars, one for each channel.
        /// </summary>
        /// <value>
        /// The level bars.
        /// </value>
        public ObservableCollection<LevelBarViewModel> LevelBars { get; set; } = new ObservableCollection<LevelBarViewModel>();

        /// <summary>
        /// Gets the command to connect the generator
        /// </summary>
        /// <value>
        /// The connect generator.
        /// </value>
        public RelayCommand ConnectGeneratorCommand => connectToGeneratorCommand ?? (connectToGeneratorCommand = new RelayCommand(new System.Action(async () => await levelBarGenerator.Connect())));

        /// <summary>
        /// Gets the command to disconnect the generator
        /// </summary>
        /// <value>
        /// The disconnect generator.
        /// </value>
        public RelayCommand DisconnectGeneratorCommand => disconnectToGeneratorCommand ?? (disconnectToGeneratorCommand = new RelayCommand(new System.Action(async () => await levelBarGenerator.Disconnect())));

        // Methods
        private void LevelBarGenerator_ChannelAdded(object sender, ChannelChangedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>    // Code to be executed on the UI thread
            {
                // Create a new LevelBarViewModel for the added channel
                var newLevelBar = new LevelBarViewModel
                {
                    Id = e.ChannelId,
                    Name = $"Channel {e.ChannelId}",
                    MaxLevel = 1.0f // Set the maximum level value for the ProgressBar
                };

                // Add the new level bar to the collection
                LevelBars.Add(newLevelBar);
            });
        }

        private void LevelBarGenerator_ChannelRemoved(object sender, ChannelChangedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>   // Code to be executed on the UI thread
            {
                // Find and remove the corresponding LevelBarViewModel
                var levelBarToRemove = LevelBars.FirstOrDefault(bar => bar.Id == e.ChannelId);
                if (levelBarToRemove != null)
                {
                    LevelBars.Remove(levelBarToRemove);

                    // Remove the peak hold value for the removed channel
                    peakHoldValues.Remove(e.ChannelId);
                }
            });
        }

        private void LevelBarGenerator_GeneratorStateChanged(object sender, GeneratorStateChangedEventArgs e)
        {
            // TODO Set the state of the generator
        }

        private void LevelBarGenerator_ChannelDataReceived(object sender, ChannelDataEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Update the level and calculate peak hold values for the corresponding LevelBarViewModel
                foreach (var levelBar in LevelBars)
                {
                    var channelIndex = levelBar.Id;
                    if (channelIndex >= 0 && channelIndex < e.ChannelIds.Length)
                    {
                        var level = e.Levels[channelIndex];
                        levelBar.Level = level;

                        // Calculate peak hold value if necessary
                        if (!peakHoldValues.ContainsKey(channelIndex) || level > peakHoldValues[channelIndex])
                        {
                            peakHoldValues[channelIndex] = level;
                        }

                        levelBar.MaxLevel = peakHoldValues[channelIndex];
                    }
                }
            });
        }

    }
}
